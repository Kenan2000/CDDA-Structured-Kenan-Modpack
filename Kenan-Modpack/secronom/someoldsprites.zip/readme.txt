These are the old sprites used in earlier versions of the secronom mod. They are based from MSXotto++'s sprites and edited for better representations of the mod's creatures.

It'll remain here, for people to see how it looked like before SomeDeadGuy's tileset rework :)