#!/usr/bin/env python3
"""
Tested with Python 3.9.5
Generate containers for the Easy Containers mod (sch_easy_containers)

Examples:

    %(prog)s data/json
    %(prog)s data/json/backpacks.json
    %(prog)s data/json/mods/Magiclysm
"""

import argparse
import pathlib
import json

OUTPUT_FOLDER = "sch_easy_containers"


class InvalidPathError(Exception):
    def __init__(self, path: pathlib.Path):
        name = "File" if path.suffix == ".json" else "Folder"
        print(f"\n{name} does not exist: {path.absolute()}\n")


class FolderExistsError(Exception):
    def __init__(self, path: pathlib.Path):
        print(f"\nFolder already exists: {path.absolute()}\n")


class VolumeUnhandledUnitError(Exception):
    def __init__(self, unit):
        print(f"\nInvalid unit {unit}\n")


def parse_filename(path: pathlib.Path, parent: pathlib.Path = None) -> str:
    if parent is None:
        if path.suffix == ".json":
            return path.name
        raise ValueError

    return str(path.relative_to(parent))


def pocket_restricted(pocket: dict) -> bool:
    restrictions = (
        "ammo_restriction",
        "item_restriction",
        "allowed_speedloaders",
        "flag_restriction",
        "sealed_data",
        "spoil_multiplier",
        "volume_multiplier",
        "watertight",
        "airtight",
        "open_container",
        "fire_protection",
        "holster")

    for restriction in restrictions:
        if restriction in pocket:
            return True
    return False


def parse_file(file: pathlib.Path) -> list:
    with open(file, 'r') as f:
        json_file = json.load(f)

    changed_containers = []
    for entry in json_file:
        if "pocket_data" not in entry or "abstract" in entry:
            continue

        merge_containers = []
        unique_containers = []

        for pocket in entry["pocket_data"]:
            if (("pocket_type" not in pocket or
                 pocket["pocket_type"] == "CONTAINER") and
                    not pocket_restricted(pocket)):
                merge_containers.append(pocket)
            else:
                unique_containers.append(pocket)

        if len(merge_containers) == 0 and len(unique_containers) == 0:
            return []

        changed_containers.append(
            (entry["type"], entry["id"], entry["name"],
             merge_containers, unique_containers))

    return changed_containers


def get_files(data_folder: pathlib.Path) -> dict:

    files = dict()
    for file in data_folder.glob("**/*.json"):

        filename = parse_filename(file, data_folder)
        if "obsolete" in filename:
            continue

        changed_containers = parse_file(file)
        if len(changed_containers):
            files[filename] = changed_containers

    return files


def create_folder(files: dict, output_folder: pathlib.Path):

    if len(files) == 0:
        return

    output_folder.mkdir(exist_ok=True)

    for filename, entries in files.items():
        for index, entry in enumerate(entries):
            new_item = {
                "type": entry[0],
                "id": entry[1],
                "copy-from": entry[1],
                "name": entry[2],
                "pocket_data": []
            }

            max_volume = 0  # in ml
            for pocket in entry[3]:
                volume_data = pocket["max_contains_volume"].split()
                if len(volume_data) != 2:
                    print("Invalid Volume Data "
                          f"{pocket['max_contains_volume']} "
                          f"in file {filename}")

                if volume_data[1].lower() == "ml":
                    max_volume += int(volume_data[0])
                elif volume_data[1].lower() == "l":
                    max_volume += 1000 * int(volume_data[0])
                else:
                    raise VolumeUnhandledUnitError(volume_data[1])

            if max_volume:
                new_item["pocket_data"].append({
                    "max_contains_volume": f"{max_volume} ml",
                    "max_contains_weight": "1000 kg",
                    "max_item_length": "1 km"
                })

            for pocket in entry[4]:
                pocket["max_contains_weight"] = "1000 kg"
                pocket["max_item_length"] = "1 km"
                if "min_item_volume" in pocket:
                    pocket.pop("min_item_volume")
                new_item["pocket_data"].append(pocket)

            entries[index] = new_item

        new_path = output_folder.joinpath(filename)
        new_path.parent.mkdir(parents=True, exist_ok=True)
        with new_path.open("w") as f:
            print(json.dumps(entries, indent=4), file=f)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument("files_location", type=str,
                        help="json file(s) location")

    parser.add_argument("-f", "--force", action='store_true',
                        help="overwrite the output folder if it exists")

    args = parser.parse_args()

    output_folder = pathlib.Path(OUTPUT_FOLDER)
    if output_folder.exists():
        if not args.force:
            raise FolderExistsError(output_folder)

    input_path = pathlib.Path(args.files_location)
    if input_path.suffix == ".json":
        if not input_path.is_file():
            raise InvalidPathError(input_path)
        files = dict()
        parsed_file = parse_file(input_path)
        if len(parsed_file):
            files[parse_filename(input_path)] = parsed_file
    else:
        if not input_path.is_dir():
            raise InvalidPathError(input_path)
        files = get_files(input_path)

    create_folder(files, output_folder)
