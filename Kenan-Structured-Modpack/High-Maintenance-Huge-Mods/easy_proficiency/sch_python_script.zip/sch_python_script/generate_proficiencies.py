#!/usr/bin/env python3
"""
Tested with Python 3.9.5
Generate proficiencies for the Easy Proficiency mod (sch_easy_proficiency)

Examples:

    %(prog)s data/json
    %(prog)s data/json/fabrication_proficiencies.json
    %(prog)s data/json/mods/Magiclysm
"""

import argparse
import pathlib
import json

OUTPUT_FOLDER = "sch_easy_proficiency"


class InvalidPathError(Exception):
    def __init__(self, path: pathlib.Path):
        name = "File" if path.suffix == ".json" else "Folder"
        print(f"\n{name} does not exist: {path.absolute()}\n")


class FolderExistsError(Exception):
    def __init__(self, path: pathlib.Path):
        print(f"\nFolder already exists: {path.absolute()}\n")


def parse_filename(path: pathlib.Path, parent: pathlib.Path = None) -> str:
    if parent is None:
        if path.suffix == ".json":
            return path.name
        raise ValueError

    return str(path.relative_to(parent))


def parse_file(file: pathlib.Path) -> list:
    with open(file, 'r') as f:
        json_file = json.load(f)

    changed_profs = []
    for entry in json_file:
        if "type" not in entry or entry["type"] != "proficiency":
            continue

        if entry["can_learn"]:
            changed_profs.append(entry["id"])
    return changed_profs


def get_files(data_folder: pathlib.Path) -> dict:

    files = dict()
    for file in data_folder.glob("**/*.json"):

        filename = parse_filename(file, data_folder)
        if "obsolete" in filename:
            continue

        changed_profs = parse_file(file)
        if len(changed_profs):
            files[filename] = changed_profs

    return files


def create_folder(files: dict, output_folder: pathlib.Path):

    if len(files) == 0:
        return

    output_folder.mkdir(exist_ok=True)

    for filename, entries in files.items():
        for index, entry in enumerate(entries):
            entries[index] = {
                "type": "proficiency",
                "id": entry,
                "copy-from": entry,
                "time_to_learn": "1 s"
            }

        new_path = output_folder.joinpath(filename)
        new_path.parent.mkdir(parents=True, exist_ok=True)
        with new_path.open("w") as f:
            print(json.dumps(entries, indent=4), file=f)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawTextHelpFormatter,
    )

    parser.add_argument("files_location", type=str,
                        help="json file(s) location")

    parser.add_argument("-f", "--force", action='store_true',
                        help="overwrite the output folder if it exists")

    args = parser.parse_args()

    output_folder = pathlib.Path(OUTPUT_FOLDER)
    if output_folder.exists():
        if not args.force:
            raise FolderExistsError(output_folder)

    input_path = pathlib.Path(args.files_location)
    if input_path.suffix == ".json":
        if not input_path.is_file():
            raise InvalidPathError(input_path)
        files = dict()
        parsed_file = parse_file(input_path)
        if len(parsed_file):
            files[parse_filename(input_path)] = parsed_file
    else:
        if not input_path.is_dir():
            raise InvalidPathError(input_path)
        files = get_files(input_path)

    create_folder(files, output_folder)
