# Not everyone turned into zombies. Some still struggling to live...

Adds 5 new side stories (1 WIP), 1 mission for random NPCs and a story line for Hell's Raiders faction (in early stage of development, fully playable, currently have a decent amount of content).

## How to get to Hell's Raiders story line:

1. Go to Refugee Center and complete first mission of Old Guard representative.
2. IMPORTANT! Talk to OG rep, FM merchant, Doctor and Broker at least ONCE. You will get 4 'You met X' missions. This step is important due to a few JSON limitations.
3. On the second mission of OG representative, find informant and choose the last reply.

Share with me your thoughts about it! Report bugs, pass me your ideas on what may or should be added, or just say Hi :)

My discord: 1123132123#2270

My other mods:

https://github.com/El-Jekozo/Wandering_Masters
